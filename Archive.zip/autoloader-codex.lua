EC = include("autoloader-codex-equipment")

local M = { EC, }

return M.EC